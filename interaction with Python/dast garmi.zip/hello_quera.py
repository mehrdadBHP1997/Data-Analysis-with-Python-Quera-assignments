# coding: utf-8
def hello_quera():
    text = "Hello Quera"
    return text
